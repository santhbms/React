var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB 
|| window.shimIndexedDB;

const request=indexedDB.open("EmployeesDB",1);//1 is version

console.log(request);

request.onerror=function(event){
  console.error('An Error Occured with IndexedDB')
  console.error(event);
};

 
request.onupgradeneeded=()=>{
    const db=request.result;
    const emp=db.createObjectStore("Employees",{keyPath:"Id"}); //id will be the key for object data
    emp.createIndex("index_name",["Name"],{unique:false});
    emp.createIndex("index_empCode",["EmpCode"],{unique:false});
    emp.createIndex("index_designation_city",["Designation","City"],{unique:false});
    emp.createIndex("index_mobile",["Mobile"],{unique:false});
};

request.onsuccess=(e)=>{
    const db=e.target.result;


   
    const transaction=db.transaction("Employees","readwrite");

    const emp=transaction.objectStore("Employees");

    const des_city=emp.index("index_designation_city");//incase to get Index of name column
    const names=emp.index("index_name");
    
    emp.put({Id:101,Name:"John",EmpCode:"HYD90105",Designation:"Manager",City:"Hyderabad",Mobile:"9848012345"});
    emp.put({Id:102,Name:"Steve",EmpCode:"MUM58985",Designation:"Developer",City:"Mumbai",Mobile:"9849012345"});
    emp.put({Id:103,Name:"Harry",EmpCode:"CHN63985",Designation:"HR",City:"Chennai",Mobile:"9948012345"});
    emp.put({Id:104,Name:"Paul",EmpCode:"HYD96610",Designation:"Manager",City:"Hyderabad",Mobile:"9748012345"});
    emp.put({Id:105,Name:"Mohan",EmpCode:"CHN65105",Designation:"HR",City:"Chennai",Mobile:"9048012345"});


    const IdQuery=emp.get(105);
    console.log("IdQuery",IdQuery);

    
    const RoleQuery=des_city.getAll(["Manager","Hyderabad"]);
    RoleQuery.onsuccess=function(){
        console.log("Managers:",RoleQuery.result);
    }

   var _emp=emp.get(103);
   _emp.onsuccess=function()
   {
    _emp.result.Name="Pawan Kalyan";
    console.log('Updating Record',_emp.result);
    const res=emp.put(_emp.result);
    res.onsuccess=()=>{
        console.log('Record Updated!');
    }
   }
   
    
    const Result2Delete=emp.delete(104);
    Result2Delete.onsuccess=()=>{
     console.log('Record Deleted!');
    };

    const data=emp.getAll();
    data.onsuccess=function(){
        console.log("All Employees",data.result);
    }
   



    transaction.oncomplete=function(){
        db.close();
    };

};