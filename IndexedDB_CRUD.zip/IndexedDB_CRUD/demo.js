

self.addEventListener("fetch", function (event) {
    event.respondWith(
    caches.match(event.request).then(function (response) {
      if (response) {
        console.log('if valid response is found in cache return it')
        return response;
        // if valid response is found in cache return it

      } else {
        return (
            
          fetch(event.request)
          //fetch from internet
          
          .then(function (res) {
            console.log('fetch from internet');
            return caches.
            open(staticCacheName).
            then(function (cache) {
              cache.put(event.request.url, res.clone());
              //save the response for future
              console.log('save the response for future');
              return res;
              
              // return the fetched data
            });
          }).
          catch(function (err) {
            // fallback mechanism
            console.log('Fallback')
            return caches.
            open(CACHE_CONTAINING_ERROR_MESSAGES).
            then(function (cache) {
              return cache.match("offline");
            });
          }));
  
      }
    }));
  
  });